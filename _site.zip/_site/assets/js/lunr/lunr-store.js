var store = [{
        "title": "SwiftUI: Project migration from UIKit",
        "excerpt":"Apple released SwiftUI framework. The great tech that will allow to create great UI/UX faster. How to migrate from old project with UIKit to new SwiftUI? It’s the first article of rewriting my very old project PoloTicker with new SwiftUI. Let’s start from migrating the project to new structure to...","categories": [],
        "tags": [],
        "url": "https://nikrodionov.com/project-migration-to-swiftui/",
        "teaser":"https://nikrodionov.com/assets/migration.jpg"},{
        "title": "iOS Common Issues #1: … this class is not key value coding-compliant for the key …",
        "excerpt":"When you just at start of becoming great iOS Developer you already have faced or definitely will face with wide range of crashes. It can be very frustrating and can be big problem on your way on learning iOS development. I think every dev has faced and knows this XCode...","categories": [],
        "tags": [],
        "url": "https://nikrodionov.com/this-class-is-not-key-value-coding-compliant-for-the-key/",
        "teaser":"https://nikrodionov.com/assets/error.jpg"},{
        "title": "rvictl in XCode 11 and MacOS Catalina",
        "excerpt":"I have faced with a problem that small and very useful program rvictl become unavailable MacOS Catalina and XCode 11. I will provide steps how to get the application back. But at first let’s take a look what rvictl is?! rvictl ( Remote Virtual Interface Tool ) is a tool...","categories": [],
        "tags": [],
        "url": "https://nikrodionov.com/rvictl-in-xcode-11-and-macos-catalina/",
        "teaser":"https://nikrodionov.com/assets/rvictl.jpg"},{
        "title": "iOS Developer Tools",
        "excerpt":"iOS Developer Tools Article describes various tools I use during my daily working routine. I update this list if something will change. It covers just tools that I use and that suits my workflow but I think that it can be helpful for someone who is seeking the new ways...","categories": [],
        "tags": [],
        "url": "https://nikrodionov.com/ios-developer-tools/",
        "teaser":"https://nikrodionov.com/assets/ios_development_tools.jpg"}]
